#ifndef __FONT_H
#define __FONT_H

// 这是一个8x16的ASCII字库，只包含了部分常用字符以作演示
// 每个字符占16个字节
extern const unsigned char asc2_1608_number[][16];
extern const unsigned char asc2_1608_UppL[][16];
// extern const unsigned char asc2_1608_LowL[][16];
//这上面字体的大小直接定死了
extern const unsigned char asc2_1608_number_Large[][240];

#endif