#include "main.h"
#include "i2c.h"
#include "SCD30.h"

#define SCD30_ADDRESS   0x61  // 7-bit 地址

/**
 * @brief  CRC-8计算（多项式0x31，初始值0xFF）
 */
uint8_t SCD30_CalcCRC8(uint8_t *data, uint8_t len) {
    uint8_t crc = 0xFF;
    for (uint8_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x80) {
                crc = (crc << 1) ^ 0x31;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc;
}

/**
 * @brief  发送I2C命令
 */
static uint8_t SCD30_I2C2_WriteCmd(uint16_t cmd, uint16_t param, uint8_t has_param) {
    uint8_t tx_buf[5] = {0};
    uint8_t tx_len = 2;

    tx_buf[0] = (cmd >> 8) & 0xFF;
    tx_buf[1] = cmd & 0xFF;

    if (has_param) {
        tx_buf[2] = (param >> 8) & 0xFF;
        tx_buf[3] = param & 0xFF;
        tx_buf[4] = SCD30_CalcCRC8(&tx_buf[2], 2);
        tx_len = 5;
    }

    if (HAL_I2C_Master_Transmit(&hi2c1, (SCD30_ADDRESS << 1), tx_buf, tx_len, HAL_MAX_DELAY) != HAL_OK) {
        return 1;
    }
    return 0;
}

/**
 * @brief  启动连续测量
 */
uint8_t SCD30_StartContinuousMeas(void) {
    return SCD30_I2C2_WriteCmd(SCD30_CMD_START_MEAS, 0x0000, 1);
}

/**
 * @brief  检查数据是否就绪
 */
static uint8_t SCD30_CheckDataReady(void) {
    uint8_t rx_buf[3] = {0};

    if (SCD30_I2C2_WriteCmd(SCD30_CMD_GET_DATA_RDY, 0, 0) != 0) {
        return 2;
    }

    HAL_Delay(SCD30_DELAY_AFTER_CMD);

    if (HAL_I2C_Master_Receive(&hi2c1, (SCD30_ADDRESS << 1), rx_buf, 3, HAL_MAX_DELAY) != HAL_OK) {
        return 2;
    }

    if (rx_buf[2] != SCD30_CalcCRC8(rx_buf, 2)) {
        return 2;
    }

    return (rx_buf[1] == 0x01) ? 0 : 1;
}

/**
 * @brief  读取测量数据
 */
uint8_t SCD30_ReadMeasData(SCD30_MeasData *data) {
    uint8_t rx_buf[18] = {0};
    uint32_t temp_u32 = 0;

    uint8_t ready_status = SCD30_CheckDataReady();
    if (ready_status == 1) return 1;
    if (ready_status == 2) return 2;

    if (SCD30_I2C2_WriteCmd(SCD30_CMD_READ_MEAS, 0, 0) != 0) {
        return 2;
    }

    HAL_Delay(SCD30_DELAY_AFTER_CMD);

    if (HAL_I2C_Master_Receive(&hi2c1, (SCD30_ADDRESS << 1), rx_buf, 18, HAL_MAX_DELAY) != HAL_OK) {
        return 2;
    }

    // CRC 校验
    for (uint8_t i = 0; i < 18; i += 3) {
        if (rx_buf[i+2] != SCD30_CalcCRC8(&rx_buf[i], 2)) {
            data->is_valid = 0;
            return 3;
        }
    }

    // 转换 CO₂ 数据
    temp_u32 = ((uint32_t)rx_buf[0] << 24) | ((uint32_t)rx_buf[1] << 16) |
               ((uint32_t)rx_buf[3] << 8) | rx_buf[4];
    data->co2_ppm = *(float*)&temp_u32;

    // 转换温度数据
    temp_u32 = ((uint32_t)rx_buf[6] << 24) | ((uint32_t)rx_buf[7] << 16) |
               ((uint32_t)rx_buf[9] << 8) | rx_buf[10];
    data->temperature_c = *(float*)&temp_u32;

    // 转换湿度数据
    temp_u32 = ((uint32_t)rx_buf[12] << 24) | ((uint32_t)rx_buf[13] << 16) |
               ((uint32_t)rx_buf[15] << 8) | rx_buf[16];
    data->humidity_rh = *(float*)&temp_u32;

    data->is_valid = 1;
    return 0;
}
