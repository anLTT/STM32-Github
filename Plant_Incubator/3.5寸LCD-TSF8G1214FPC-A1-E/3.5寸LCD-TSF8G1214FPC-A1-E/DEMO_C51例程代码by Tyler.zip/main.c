// SPI
#define HAL_BOARD_IO_SPI_MISO_PORT     1
#define HAL_BOARD_IO_SPI_MISO_PIN      7
#define HAL_BOARD_IO_SPI_MOSI_PORT     1  //MOSI/SDI P1.3
#define HAL_BOARD_IO_SPI_MOSI_PIN      3  
#define HAL_BOARD_IO_SPI_CLK_PORT      1   //CLK P1.2
#define HAL_BOARD_IO_SPI_CLK_PIN       2 
//#define HAL_BOARD_IO_EM_CS_PORT        1
//#define HAL_BOARD_IO_EM_CS_PIN         4

// LCD
#define HAL_BOARD_IO_LCD_CS_PORT       0  //DC P0.0
#define HAL_BOARD_IO_LCD_CS_PIN        0
#define HAL_BOARD_IO_LCD_RST_PORT       0  //RST P0.7
#define HAL_BOARD_IO_LCD_RST_PIN        7
//#define HAL_BOARD_IO_LCD_MODE_PORT     0
//#define HAL_BOARD_IO_LCD_MODE_PIN      0



void halLcdSpiInit(void)
{
    MCU_IO_OUTPUT(HAL_BOARD_IO_SPI_MOSI_PORT, HAL_BOARD_IO_SPI_MOSI_PIN, 1);
    MCU_IO_OUTPUT(HAL_BOARD_IO_SPI_CLK_PORT,  HAL_BOARD_IO_SPI_CLK_PIN, 1);
    MCU_IO_OUTPUT(HAL_BOARD_IO_LCD_CS_PORT, HAL_BOARD_IO_LCD_CS_PIN, 1);
    MCU_IO_OUTPUT(HAL_BOARD_IO_LCD_RST_PORT, HAL_BOARD_IO_LCD_RST_PIN, 1);
     
    LCD_CS_SET;    //Ƭѡ�˿� 
    LCD_RST_SET;
}


void main(void)
{

    //LCD SPI port
    TrulyLCD_Init();

    halMcuWaitMs(350);  //��ʱ�ȶ�



    //����Һ����
    //Truly240160LCD_display_blocks(0xf0,0xf0,0xf0);
    //Truly240160LCD_display_240x160(BMP);
    display_string_8x16(0,0,"a brown fox jumps over");
    display_string_8x16(0,16,"abcd0123456789");
    display_ChineseStr_16x16(0,2,0);
    display_ChineseStr_16x16(1,2,1);
    display_ChineseStr_16x16(2,2,2);
    display_ChineseStr_16x16(3,2,3);
    display_ChineseStr_16x16(0,3,4);
    display_ChineseStr_16x16(1,3,5);
    display_ChineseStr_16x16(2,3,6);
    display_ChineseStr_16x16(3,3,7);
    
    mCount=0;
    mTurnFlag=0;

    // Main loop
    while (TRUE) {
        if(gCount++>15000){
            gCount=0;
            HAL_LED_TGL_1();  //toggle LED1 indicator!
//            mCount++;
//            if(mCount>4){
//                mCount=0;
//                if(0==mTurnFlag){
//                    mTurnFlag=1;
//                    Truly240160LCD_display_blocks(0xf0,0xf0,0xf0);
//                }else{
//                    mTurnFlag=0;
//                    Truly240160LCD_display_blocks(0x55,0x55,0x55);
//                }
//            }
        }
// Role is undefined. This code should not be reached
    HAL_ASSERT(FALSE);
}