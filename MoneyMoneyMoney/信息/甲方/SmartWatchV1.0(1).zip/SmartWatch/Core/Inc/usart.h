/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */
#include "stm32f1xx_hal_usart.h"
#include "GPS.h"
/* USER CODE END Includes */

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

void MX_USART1_UART_Init(void);
void MX_USART2_UART_Init(void);

/* USER CODE BEGIN Prototypes */
typedef struct
{
  uint8_t pucRcvBuf[SERIAL_RCV_BUF_LEN];
  uint16_t usRcvLen;        // * 接收的数据长度(驱动层)
  uint16_t usRcvProcessLen; // * 接收的数据长度(应用层)
  uint8_t pucSndBuf[SERIAL_SND_BUF_LEN];
  uint16_t usSndLen;
  uint8_t ucTimeOut;
  uint16_t usErrTimeOut;
}ST_SERIAL;

extern ST_SERIAL g_stSerial1;
extern ST_SERIAL g_stSerial2;


extern void Uart_Rcv_Rdy(uint8_t ucUARTNum);
extern void Uart_TimeOut(void);
extern void Uart_ErrCheck(void);
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
