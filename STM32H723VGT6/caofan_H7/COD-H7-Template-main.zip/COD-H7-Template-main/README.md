# 2025RoboMaster辽宁科技大学COD战队电控通用控制系统(达妙MC02 STM32H723VGT6)

## **1** **简介**

开发工具：Keil V5.38 STM32CubeMX V6.12.0 VsCode

软件环境：Windows11

硬件环境：达妙MC-02开发板 (STM32H723VGT6) [购买链接](https://item.taobao.com/item.htm?spm=a21n57.sem.item.1.11333903KJqSFo&priceTId=213e002217390905362315413e1b2b&utparam=%7B%22aplus_abtest%22%3A%223b7279edadc7c1c9bb817ff888417af7%22%7D&id=814954787248&ns=1&abbucket=15&xxc=taobaoSearch&skuId=5681498675796&pisk=gfjKxwtqq5VnVvNYTMzMEkdeuTwMyPXEX6WjqQAnP1COn1wer7WWF3C1ZJRhFW5R2C6P-exBZUd5i_plxgjR70BVUM2eqJ-FL3-7iSqDw9We4UduSmsp1c9FCLgWPPx_ORFNUSq0mOUBL3X_iMj_RWpen0tWRUTs1CJmdQ1WRli6_LJSOLiQBRpy1LgBOLg6CKJ2N01SVh96KKnSO0iB5d9e1QtWV_6_BLDE08AszQiRkSLJjhDFM0i5XpL_StA6bhekBeefpCi7GGpKgI6B60iWtTcVyOB39mWMYO1vn6qsvsBVb1p1GuF94175NLC_0bxFo6S2WOzjfOxp_E9ff8iXZMQGhCKxFk69vBLfxeMoqs6OFZYOj-Z2vHOCrHWoHWXOv6XFXTDS5HKhWEIpcolBZNXA2LIzalCA3G59CsZ8OgJdmiBdqjAvE2wTB4uyRdrDKGTIwgRKGdd0pz0rzF4XBI2TB4uyRdJ9iRjxz48gl)

编译工具：Arm Compiler V6.19，C/C++编译

剩下内容请阅读[README.pdf](./README.pdf)

![](.\ad140e9c0190149d99c92ce133efdfd.jpg)